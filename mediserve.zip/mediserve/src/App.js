import React, { Component, Fragment } from 'react';
import { BrowserRouter as Router, Route,Switch } from 'react-router-dom'
import './App.css'

//import PatientsList from './Components/Patients copy/PatientsList' //Copy
import Patients from './Components/Patients/PatientsList'
import Register from './Components/Register/Register'
// import Reg from './Components/Register/Reg'

import Layout from './Components/Layout'
import NotFound from './Components/404/404'
import Snack from './Components/snack';
import axios from 'axios'
import ViewPatients from './Components/Patients/ViewPatients';
import Patient from './Components/Patients/Patient';
import http from 'http'


class App extends Component {

state={
  patients: []
}

// Get user Data
componentDidMount() {
  
  axios.get('http://localhost:9200/patientsdata/patient/_search?pretty&size=40')
   // .then(res=> console.log(res))
   .then(res => this.setState({patients: res.data.hits.hits}))
   // .then(res => this.setState({data: res.data}))
  .catch(function (error){
      if(error.res){
          // The request was made and the server responded with a status code
          // that falls out of the range of 2xx
          console.log(error.res.data);
          console.log(error.res.status);
          console.log(error.res.headers);
      }else if(error.request){
          // `error.request` is an instance of XMLHttpRequest in the browser and an instance of http.ClientRequest
          console.log(error.request);

      }else {
          console.log('Error', error.message)
      }
  })
 
}


  render() {
    return(
      <Router>
        <Fragment>
          <Layout> {/* Layout.js to use the routes defined*/}
            <Switch> {/*Makes the routes to let only 404 to render undefined urls*/}
              <Route exact path="/" render= {() => <Patients/>} />
              {/*<Route  path="/Patients" render= {() => <PatientsList patients={this.state.patients}/>} /> {/*Copy*/}
              <Route  path="/Doctors" render= {() => <div>Doctors</div>} />
              <Route  path="/Patients" render= {() => <ViewPatients/>} />
              <Route  path="/register" render= {() => <Patients/>} />
              <Route  path="/p" render= {() => <Patient/>} />
              <Route  path="/Reg" render= {() => <Register/>} />
              <Route  path="/snack" render= {() => <Snack/>} />
              {/* <Route  path="/Reg2" render= {() => <Reg/>} /> */}
              <Route  render= {() => <NotFound />} />
            </Switch>
          </Layout>
        </Fragment>
      </Router>
      
    )
  }

}

export default App