import React from 'react'
import axios from 'axios'
import Snackbar from '@material-ui/core/Snackbar';
// import classNames from 'classnames'
import { withStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import '../../App.css'
import Tooltip from '@material-ui/core/Tooltip'
import FormHelperText from "@material-ui/core/FormHelperText";
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Add from '@material-ui/icons/Save';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { FormControl, InputLabel, NativeSelect, Input, Typography } from '../../../node_modules/@material-ui/core';

const styles = theme => ({
    root: {
        ...theme.mixins.gutters(),
        paddingTop: theme.spacing.unit * 2,
        paddingBottom: theme.spacing.unit * 2,
      },
    container: {
      display: 'flex',
      flexWrap: 'wrap',
    },
    appFrame: {
        // width: 360,
        // height: 360,
        // backgroundColor: theme.palette.background.paper,
        bottom: 20,
        right: "18.5%",
        zIndex: 9999,
        position: "fixed",
        // position: "reletive",
      },
    button: {
        margin: theme.spacing.unit,
      },
    textField: {
      marginLeft: theme.spacing.unit,
      marginRight: theme.spacing.unit,
      width: '100%'
    },
    box:{
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        position: 'reletive',
        display: 'block',
        width:'100%',
        padding: 20,
        paddingRight: 30,
        // boxShadow:'0px 0px 10px 1px rgba(0,0,0,0.2)',
    },
    menu: {
      width: 200,
    },

    // formControl: {
    //     margin: theme.spacing.unit,
    //     minWidth: 120,
    //   },
      selectEmpty: {
        marginTop: theme.spacing.unit * 2,
      },
      absolute: {
        // display: 'inline-block',
        position: 'absolute',
        // position: 'reletive',
        right: 75,
      },
      btnLeft: {
          position: 'reletive',
          left: 10
      },
      FormHelperText:{
          top: '-20',
          paddingLeft: '10px'
      },
    //   Snackbar stying bellow
      fabMoveUp: {
        transform: 'translate3d(0, -46px, 0)',
        transition: theme.transitions.create('transform', {
          duration: theme.transitions.duration.enteringScreen,
          easing: theme.transitions.easing.easeOut,
        }),
      },
      fabMoveDown: {
        transform: 'translate3d(0, 0, 0)',
        transition: theme.transitions.create('transform', {
          duration: theme.transitions.duration.leavingScreen,
          easing: theme.transitions.easing.sharp,
        }),
      },
      snackbar: {
        position: 'absolute',
        left: -30
      },
      label:{
        width: 135,
      },
    //   snackbarContent: {
    //     width: 360,
    //     color: 'red'
    //   },
      snackbarContent: {
        width: 360,
        backGroundColor: 'red'
      },
      formControl: {
        margin: theme.spacing.unit,
        minWidth: 120,
      },
  });
  


 class Register extends React.Component{

    state= { 
        title : '',
        titleError : '',
        firstname: '',
        firstnameError: '',
        lastname : '',
        lastnameError : '',
        idNumber : '',
        idNumberError: '',
        ocupation : '',
        ocupationError : '',
        employer : '',
        employerError : '',
        
        address : '',
        addressError : '',
        city : '',
        cityError : '',
        suburb : '',
        suburbError : '',
        street : '',
        streetError : '',
        
        cellNumber : '',
        cellNumberError : '',
        telephone : '',
        telephoneError : '',
        email : '',
        emailError : '',
        postalAddress : '',
        postalAddressError : '',

        medicalScheme: '',
        medicalSchemeError: '',
        memberNo : '',
        memberNoError : '',
        principleMember : '',
        principleMemberError : '',
        payerName: '',
        payerNameError: '',
        payerSurname: '',
        payerSurnameError: '',
        
        // Newley Added
        payerCell: '',
        payerTel: '',
        payerEmail: '',
        // Newley Added
        
        medicalPayerAddress : '',
        medicalPayerAddressError : '',
        medicalPayerCity: '',
        medicalPayerCityError: '',
        medicalPayerSuburb : '',
        medicalPayerSuburbError : '',
        medicalPayerStreet : '',
        medicalPayerStreetError : '',
        gapCover : '',
        gapCoverError : '',


        

        // title: '',
        // titleError: '',
        // firstName: '',
        // firstNameError: '',
        // lastname: '',
        // lastnameError: '',
        // email: '',
        // emailError: '',
        // dob: '',
        // dobError: '',
        // gender: '',
        // genderError: '',
        // message : '',
        valid: false,
        Dropdown: false,
        open: false,
        bgColor: 'red'
    }

    handleChange = event => {
        // this.setState({name: event.target.value})
        // this.setState({lastname: event.target.value})
        // this.setState({email: event.target.value})
        // this.setState({dob: event.target.value})
        // this.setState({gender: event.target.value})
        let change = {}
        change[event.target.name] = event.target.value
        this.setState(change)
    }
    handleClose = () => {
        this.setState({ open: false });
      };

    validate = () => {
        let isError = false;

        

        const errors = {}
        if( this.state.idNumber.length === 0){
            isError =true;
            errors.idNumberError = "Please fill Id"
            errors.valid = false
        }else if(this.state.idNumber.length < 13){
            isError =true;
            errors.idNumberError = "Id number Too short"
            errors.valid = false
        }else if(this.state.idNumber.length > 13){
            isError =false;
            errors.idNumberError = ""
            errors.valid = true
        }

        if (this.state.firstname.length === 0){
            isError =true;
            errors.firstnameError = "Please fill in firstName"
            errors.valid = false
        }else if(this.state.firstname.length < 3){
            isError =true;
            errors.firstnameError = "Name Too short"
            errors.valid = false
        }

        if( this.state.lastname.length === 0){
            isError =true;
            errors.lastnameError = "Please enter lastname"
            errors.valid = false
        }else if( this.state.lastname.length < 3){
            isError =true;
            errors.lastnameError = "Lastname too short"
            errors.valid = false
        }

        if( this.state.email.length === 0 ){
            isError =true;
            errors.emailError = "Enter Email"
            errors.valid = false
        }else if( this.state.email.length < 5){
            isError =true;
            errors.emailError = "Email Toos short"
            errors.valid = false
        }
		
		if( this.state.title.length === 0 ){
            isError =true;
            errors.titleError = "Please Enter Title"
            errors.valid = false
        }

        if( this.state.ocupation.length === 0 ){
            isError =true;
            errors.ocupationError = "Enter Ocupation"
            errors.valid = false
        }else if(this.state.ocupation.length <3 ){
            isError =true;
            errors.ocupationError = "Enter Valid Ocupation"
            errors.valid = false
        }

        if( this.state.employer.length === 0 ){
            isError =true;
            errors.employerError = "Enter Employer Name"
            errors.valid = false
        }

        if( this.state.address.length === 0 ){
            isError =true;
            errors.addressError = "Enter Address"
            errors.valid = false
        }else if(this.state.address.length <3 ){
            isError =true;
            errors.addressError = "Enter Valid Address"
            errors.valid = false
        }

        if( this.state.city.length === 0 ){
            isError =true;
            errors.cityError = "Enter City"
            errors.valid = false
        }else if(this.state.city.length <3 ){
            isError =true;
            errors.cityError = "Enter Valid City"
            errors.valid = false
        }

        if( this.state.suburb.length === 0 ){
            isError =true;
            errors.suburbError = "Enter suburb"
            errors.valid = false
        }else if(this.state.suburb.length <3 ){
            isError =true;
            errors.suburbError = "Enter Valid suburb"
            errors.valid = false
        }

        if( this.state.street.length === 0 ){
            isError =true;
            errors.streetError = "Enter street"
            errors.valid = false
        }else if(this.state.street.length <3 ){
            isError =true;
            errors.streetError = "Enter Valid street"
            errors.valid = false
        }

        if( this.state.cellNumber.length === 0 ){
            isError =true;
            errors.cellNumberError = "Enter Cell Number"
            errors.valid = false
        }else if(this.state.cellNumber.length <10 ){
            isError =true;
            errors.cellNumberError = "Enter Valid Cell Number"
            errors.valid = false
        }
        else if(this.state.cellNumber.length > 10 ){
            isError =true;
            errors.cellNumberError = "Enter Exceeds maximum"
            errors.valid = false
        }

        // if( this.state.telephone.length === 0 ){
        //     isError =true;
        //     errors.telephoneError = "Enter Telephone Number"
        //     errors.valid = false
        // }else if(this.state.telephone.length <10 ){
        //     isError =true;
        //     errors.telephoneError = "Enter Valid Cell Number"
        //     errors.valid = false
        // }
        if( this.state.postalAddress.length === 0 ){
            isError =true;
            errors.postalAddressError = "Enter Cell postalAddress"
            errors.valid = false
        }else if(this.state.postalAddress.length <3 ){
            isError =true;
            errors.postalAddressError = "Enter Valid postalAddress"
            errors.valid = false
        }




        if(isError){
            this.setState({
                ...this.state,
                ...errors
            })
        }
        return isError
    }


    handleSubmit = event => {
        event.preventDefault();

        // const newPatient ={

        // title : this.state.title,
        // firstname: this.state.firstname,
        // lastname : this.state.lastname,
        // idNumber : this.state.idNumber,
        // ocupation : this.state.ocupation,
        // employer : this.state.employer,
        
        // address : this.state.address,
        // city : this.state.city,
        // suburb : this.state.suburb,
        // street : this.state.street,
        
        // cellNumber : this.state.cellNumber,
        // telephone : this.state.telephone,
        // email : this.state.email,
        // postalAddress : this.state.postalAddress,

        // medicalScheme: this.state.medicalScheme,
        // memberNo : this.state.memberNo,
        // principleMember : this.state.principleMember,
        // payerName: this.state.payerName,
        // payerSurname: this.state.payerSurname,
        // // Newley Added
        // payerCell: this.state.payerCell,
        // payerTel: this.state.payerTel,
        // payerEmail: this.state.payerEmail,
        // // End of Newly Added
        // medicalPayerAddress : this.state.medicalPayerAddress,
        // medicalPayerCity: this.state.medicalPayerCity,
        // medicalPayerSuburb : this.state.medicalPayerSuburb,
        // medicalPayerStreet : this.state.medicalPayerStreet,
        // gapCover : this.state.gapCover,
        // }


         const newPatient = {
            personal: 
              {
                title: this.state.title,
                firstname: this.state.firstname,
                lastname: this.state.lastname,
                idNumber: this.state.idNumber,
                ocupation: this.state.ocupation,
                employer: this.state.employer
              }
            , contacts:
                {
                  address: this.state.address,
                  city: this.state.city,
                  suburb: this.state.suburb,
                  street: this.state.street,
                  cellNumber: this.state.cellNumber,
                  telephone: this.state.telephone,
                  email: this.state.email,
                  postalAddress: this.state.postalAddress
                }
              , medical:
                  {
                    medicalScheme: this.state.medicalScheme,
                    memberNo: this.state.memberNo,
                    principleMember: this.state.principleMember,
                    payerName: this.state.payerName,
                    payerSurname: this.state.payerSurname,
                    payerCell:this.state.payerCell,
                    payerTel:this.state.payerTel,
                    payerEmail:this.state.payerEmail,
                    medicalPayerAddress: this.state.medicalPayerAddress,
                    medicalPayerCity: this.state.medicalPayerCity,
                    medicalPayerSuburb: this.state.medicalPayerSuburb,
                    medicalPayerStreet: this.state.medicalPayerStreet,
                    gapCover: this.state.gapCover
                  }
                
          }

        // connection to the server and passing newPatient as an object 
        

        const err = this.validate();
            const uuidv1 = require('uuid/v1');
            let id = uuidv1()
            console.log("Id "+id)
        if(!err){
            
            try {
                const url = 'http://localhost:9200/patientsdata/patient/'+id 
                axios.post(url, newPatient)
            .then(res => {
                console.log(res)                
                this.setState({address: ''})
                this.setState({city: ''})
                this.setState({suburb: ''})
                this.setState({street: ''})
                
                this.setState({cellNumber: ''})
                this.setState({telephone: ''})
                this.setState({email: ''})
                this.setState({postalAddress: ''})

                this.setState({medicalScheme: ''})
                this.setState({MemberNo: ''})
                this.setState({principleMember: ''})
                this.setState({payerName: ''})
                this.setState({payerSurname: ''})
                
                this.setState({medicalPayerAddress: ''})
                this.setState({medicalPayerCity: ''})
                this.setState({medicalPayerSuburb: ''})
                this.setState({medicalPayerStreet: ''})
                this.setState({gapCover: ''})
                this.setState({open: true})
                this.setState({message:' NEW PATIENT ADDED SUCCESSFULLY'})
                this.setState({bgColor:'green'})
             })
            .catch(err => {
                console.log("Error "+err)
            })
            } catch (error) {
                console.log(error.message)
            }
            
            
            // ClearForm
            
        }else{
            this.setState({message:'Failed to submit form'})
            this.setState({open: true})
            this.setState({bgColor:'red'})

        }
    }

    resetForm = () => {

        this.setState({
            address: '',
            city: '',
            suburb: '',
            street: '',
            
            cellNumber: '',
            telephone: '',
            email: '',
            postalAddress: '',

            medicalScheme: '',
            MemberNo: '',
            principleMember: '',
            payerName: '',
            payerSurname: '',
            
            medicalPayerAddress: '',
            medicalPayerCity: '',
            medicalPayerSuburb: '',
            medicalPayerStreet: '',
            
            idError: '',
            isError: false,
            firstNameError: '',
            lastnameError: '',
            emailError: '',
            genderError: '',
            valid: false,

        })
    } 

    handleClick = () => {
        this.setState({ open: true });
    };
    
    handleClose = () => {
    this.setState({ open: false });
    
    };

    render(){
        const { classes } = this.props;
        const { open,bgColor } = this.state;
        // const fabClassName = classNames(classes.fab, open ? classes.fabMoveUp : classes.fabMoveDown);
        return(
            <form className="popOverForm" onSubmit={this.handleSubmit}>
                <div className={classes.box}>

                    <Typography variant="display1">REGISTER PATIENT</Typography>
                    <br />
                    <br />
                    <Typography variant="title">- About Me</Typography>
                    <br />
                    <FormControl className={classes.textField}>
						<InputLabel>Title</InputLabel>
						<NativeSelect
							value={this.state.title}
							onChange={e => this.setState({title: e.target.value}) && this.handleChange.bind(this)}
							input={<Input name="age" id="age-native-helper" />}>  
							<option value=""/>
							<option value="Mr">Mr</option>
							<option value="Mrs">Mrs</option>
							<option value="Ms">Ms</option>
							<option value="Dr">Dr</option>
							<option value="Dr">Prof</option>
						</NativeSelect>
						<FormHelperText id="name-error-text" margin="dense" error>{this.state.titleError}</FormHelperText>
                    </FormControl>

					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="Firstname" 
							name="firstName" 
							value={this.state.firstname}
							onChange={e => this.setState({firstname: e.target.value}) && this.handleChange.bind(this)}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error>{this.state.firstnameError}</FormHelperText>
					</FormControl>

					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="Lastname" 
							name="lastname"
							value = {this.state.lastname}
							onChange={e => this.setState({lastname: e.target.value}) && this.handleChange.bind(this) && this.handleError}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error >{this.state.lastnameError}</FormHelperText>
						</FormControl>
                        
					<FormControl className={classes.textField}>
						<TextField 
							type="number" 
							label="Id Number" 
							name="idNumber" 
							value = { this.state.idNumber}
							onChange={e => this.setState({idNumber: e.target.value}) && this.handleChange.bind(this)}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error >{this.state.idNumberError}</FormHelperText>
					</FormControl>
					
					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="Ocupation" 
							name="ocuption" 
							value = { this.state.ocupation }
							onChange={e => this.setState({ocupation: e.target.value}) && this.handleChange.bind(this)}
							margin="normal"/>  
						<FormHelperText id="name-error-text" margin="dense" error= {true} >{this.state.ocupationError}</FormHelperText>
					</FormControl>

					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="Employer" 
							name="employer" 
							value = { this.state.employer }
							onChange={e => this.setState({employer: e.target.value}) && this.handleChange.bind(this)}
							margin="normal"/>  
						<FormHelperText id="name-error-text" margin="dense" error= {true} >{this.state.employerError}</FormHelperText>
					</FormControl>
				</div>


                    <br/><br/>


                <div className={classes.box}>
                    <Typography variant="title" >- Where Do I Live</Typography>
					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="Address" 
							name="address" 
							value={this.state.address}
							onChange={e => this.setState({address: e.target.value}) && this.handleChange.bind(this)}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error>{this.state.addressError}</FormHelperText>
					</FormControl>

					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="City" 
							name="city" 
							value={this.state.city}
							onChange={e => this.setState({city: e.target.value}) && this.handleChange.bind(this)}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error>{this.state.cityError}</FormHelperText>
					</FormControl>

					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="Suburb" 
							name="surburb" 
							value = {this.state.suburb}
							onChange={e => this.setState({suburb: e.target.value}) && this.handleChange.bind(this) && this.handleError}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error >{this.state.suburbError}</FormHelperText>
					</FormControl>
				
					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="Street" 
							name="street" 
							value = { this.state.street }
							onChange={e => this.setState({street: e.target.value}) &&  this.handleChange.bind(this)}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error >{this.state.streetError}</FormHelperText>
					</FormControl>
                </div>

                    <br/><br/>

                <div className={classes.box}> {/* My Contact Details */}
                    <Typography variant="title" >- My Contact Details</Typography>

					<FormControl className={classes.textField}>
						<TextField 
							type="number" 
							label="Cell No" 
							name="cellNumber" 
							value={this.state.cellNumber}
							onChange={e => this.setState({cellNumber: e.target.value}) && this.handleChange.bind(this)}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error>{this.state.cellNumberError}</FormHelperText>
					</FormControl>

					<FormControl className={classes.textField}>
						<TextField 
							type="number" 
							label="Telephone" 
							name="telephone" 
							value = {this.state.telephone}
							onChange={e => this.setState({telephone: e.target.value}) && this.handleChange.bind(this) && this.handleError}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error >{this.state.telephoneError}</FormHelperText>
					</FormControl>

					<FormControl className={ classes.textField }>
						<TextField 
							type="email" 
							label="Email" 
							name="email"
							value = { this.state.email }
							onChange={e => this.setState({email: e.target.value}) &&  this.handleChange.bind(this)}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error >{this.state.emailError}</FormHelperText>
					</FormControl>

					<FormControl className={classes.textField}>
						<TextField 
							type="text" 
							label="Postal Adress" 
							name="postalAddress" 
							value={this.state.postalAddress}
							onChange={e => this.setState({postalAddress: e.target.value}) && this.handleChange.bind(this)}
							margin="normal"/>
						<FormHelperText id="name-error-text" margin="dense" error>{this.state.postalAddressError}</FormHelperText>
					</FormControl>
                </div>

                <br/><br/>

                <div className={classes.box}> {/* My Contact Details */}
                    <Typography variant="title" >- Who is responsible for payment</Typography>
                    
                    <TextField 
                        type="text" 
                        label="medical Scheme" 
                        name="medicalScheme" 
                        value={this.state.medicalScheme}
                        className={classes.textField} 
                        onChange={e => this.setState({medicalScheme: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error>{this.state.medicalSchemeError}</FormHelperText>

                    <TextField 
                        type="number" 
                        label="Member number" 
                        name="memberNumber " 
                        value = {this.state.memberNo}
                        className={classes.textField} 
                        onChange={e => this.setState({memberNo: e.target.value}) && this.handleChange.bind(this) && this.handleError}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error >{this.state.memberNoError}</FormHelperText>
                   
                    <TextField 
                        type="text" 
                        label="Principle Member" 
                        name="principleMember" 
                        value={this.state.principleMember}
                        className={classes.textField} 
                        onChange={e => this.setState({principleMember: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error>{this.state.principleMemberError}</FormHelperText>

                    <TextField 
                        type="text" 
                        label="First Name" 
                        name="payerName" 
                        value={this.state.payerName}
                        className={classes.textField} 
                        onChange={e => this.setState({payerName: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error>{this.state.payerNameError}</FormHelperText>

                    <TextField 
                        type="text" 
                        label="Last Name" 
                        name="lastName" 
                        value={this.state.payerSurname}
                        className={classes.textField} 
                        onChange={e => this.setState({payerSurname: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error>{this.state.payerSurnameError}</FormHelperText>

                </div>

                <br/><br/>

                <div className={classes.box}> {/* My Contact Details */}
                    <Typography variant="title" >- Contact Details of Payer</Typography>
                    
                    <TextField 
                        type="text" 
                        label="Address" 
                        name="medicalPayerAddress" 
                        value={this.state.medicalPayerAddress}
                        className={classes.textField} 
                        onChange={e => this.setState({medicalPayerAddress: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error>{this.state.medicalPayerAddressError}</FormHelperText>

                    <TextField 
                        type="text" 
                        label="City" 
                        name="medicalPayerCity" 
                        value = {this.state.medicalPayerCity}
                        className={classes.textField} 
                        onChange={e => this.setState({medicalPayerCity: e.target.value}) && this.handleChange.bind(this) && this.handleError}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error >{this.state.medicalPayerCityError}</FormHelperText>
                   
                    <TextField 
                        type="text" 
                        label="Suburb" 
                        name="medicalPayerSuburb" 
                        value={this.state.medicalPayerSuburb}
                        className={classes.textField} 
                        onChange={e => this.setState({medicalPayerSuburb: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error>{this.state.medicalPayerSuburbError}</FormHelperText>

                    <TextField 
                        type="text" 
                        label="Street" 
                        name="medicalPayerStreet" 
                        value={this.state.medicalPayerStreet}
                        className={classes.textField} 
                        onChange={e => this.setState({medicalPayerStreet: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    <FormHelperText id="name-error-text" margin="dense" error>{this.state.medicalPayerStreetError}</FormHelperText>

                    <FormControl className={classes.textField}>
                    <InputLabel>Gap Cover</InputLabel>
                    <NativeSelect
                        value={this.state.gapCover}
                        onChange={e => this.setState({gapCover: e.target.value}) && this.handleChange.bind(this)}
                        input={<Input name="gapCover" id="gapCover" />}>  
                        <option value=""/>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </NativeSelect>
                    <FormHelperText id="name-error-text" margin="dense" error>{this.state.gapCoverError}</FormHelperText>
                    </FormControl>

                </div>

                <br/><br/>
                
                <div className={classes.box}>

                    <Tooltip title="Add new Patient">
                        <Button variant="contained" size="large"  aria-label="Add" type="submit" margin="normal" className={classes.btnLeft} >
                            <Add/> Add
                        </Button>
                    </Tooltip>

                    <Tooltip title="Clear form">
                        <Button variant="contained" size="large"  onReset={this.resetForm} type="reset" margin="normal" className={classes.absolute}>
                            <CloseIcon/> Clear
                        </Button>
                    </Tooltip>

                </div>
                <br />
                <br />
                <div className={classes.appFrame}>

                    <Snackbar
                        open={open}
                        autoHideDuration={4000}
                        onClose={this.handleClose}
                        ContentProps={{
                        'aria-describedby': 'snackbar-fab-message-id',
                        style:{backgroundColor: bgColor}
                        }}
                        variant="success"
                        message={<span id="snackbar-fab-message-id">{this.state.message}</span>}
                        action={
                        <IconButton className="cornerBtn" onClick={this.handleClose}>
                            <CloseIcon/>
                        </IconButton>
                        }
                        className={classes.snackbar}
                    />
                    
                </div>
            </form>
        )
    }
} 

export default withStyles(styles, { withTheme: true })(Register)