import React from 'react'
import axios from 'axios'
import Snackbar from '@material-ui/core/Snackbar';
import { withStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import '../../App.css'
import Tooltip from '@material-ui/core/Tooltip'
import FormHelperText from "@material-ui/core/FormHelperText";
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close'
import { FormControl, InputLabel, NativeSelect, Input, Typography } from '../../../node_modules/@material-ui/core';

const styles = theme => ({
    root: {
        ...theme.mixins.gutters(),
        paddingTop: theme.spacing.unit * 2,
        paddingBottom: theme.spacing.unit * 2,
      },
    container: {
      display: 'flex',
      flexWrap: 'wrap',
    },
    appFrame: {
        bottom: 20,
        right: "18.5%",
        zIndex: 9999,
        position: "fixed",
      },
    button: {
        margin: theme.spacing.unit,
      },
    textField: {
      marginLeft: theme.spacing.unit,
      marginRight: theme.spacing.unit,
      width: '100%'
    },
    box:{
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        position: 'reletive',
        display: 'block',
        width:'100%',
        padding: 20,
        paddingRight: 30,
    },
    menu: {
      width: 200,
    },

      selectEmpty: {
        marginTop: theme.spacing.unit * 2,
      },
      absolute: {
        display: 'inline-block',
        position: 'absolute',
        right: 75,
      },
      btnLeft: {
          position: 'reletive',
          left: 10
      },
      FormHelperText:{
          top: '-20',
          paddingLeft: '10px'
      },
    //   Snackbar stying bellow
      fabMoveUp: {
        transform: 'translate3d(0, -46px, 0)',
        transition: theme.transitions.create('transform', {
          duration: theme.transitions.duration.enteringScreen,
          easing: theme.transitions.easing.easeOut,
        }),
      },
      fabMoveDown: {
        transform: 'translate3d(0, 0, 0)',
        transition: theme.transitions.create('transform', {
          duration: theme.transitions.duration.leavingScreen,
          easing: theme.transitions.easing.sharp,
        }),
      },
      snackbar: {
        position: 'absolute',
        left: -30
      },
      snackbarContent: {
        width: 360,
        backGroundColor: 'red'
      },
      formControl: {
        margin: theme.spacing.unit,
        minWidth: 120,
      },
  });
  
 class EditPatient extends React.Component {

    constructor (props) {
        super();
        this.state = {
            title : '',
            titleError : '',
            firstname: '',
            firstnameError: '',
            lastname : '',
            lastnameError : '',
            idNumber : '',
            idNumberError: '',
            ocupation : '',
            ocupationError : '',
            employer : '',
            employerError : '',
            
            address : '',
            addressError : '',
            city : '',
            cityError : '',
            suburb : '',
            suburbError : '',
            street : '',
            streetError : '',
            
            cellNo : '',
            cellNoError : '',
            telephone : '',
            telephoneError : '',
            email : '',
            emailError : '',
            postalAdress : '',
            postalAdressError : '',
            
            medicalScheme: '',
            medicalSchemeError: '',
            memberNo : '',
            memberNoError : '',
            principleMember : '',
            principleMemberError : '',
            payerName: '',
            payerNameError: '',
            payerSurname: '',
            payerSurnameError: '',
            
            medicalPayerAddress : '',
            medicalPayerAddressError : '',
            medicalPayerCity: '',
            medicalPayerCityError: '',
            medicalPayerSuburb : '',
            medicalPayerSuburbError : '',
            medicalPayerStreet : '',
            medicalPayerStreetError : '',
            gapCover : '',
            gapCoverError : '',
            
            id: props.selId,
            patient : props.user,
            editPatient: '',
            editedPatient: ''
        }
    }

    handleChange = event => {
        let change = {}
        change[event.target.name] = event.target.value
        this.setState(change)
    }
    
    componentDidMount =() =>{
        let patientSelect = this.state.id
        // this.setState({patientId: patientSelect})
        console.log("Editing  " +patientSelect)
        let uri = 'http://localhost:9200/patientsdata/patient'
        axios.get(uri+'/'+patientSelect)
        .then(res => {
          this.setState({editPatient: res.data._source})
          let fname = this.state.editPatient.firstname
        this.setState({firstname: fname})
          console.log("Got Patient "+ this.state.firstname)
        })
        this.setState({showPatientInfor:true})
      }
    render(){
        const { classes } = this.props
        return(
            <form className="popOverPersonDetails" onSubmit={this.handleSubmit}>
                <div className={classes.box}>

                    <Typography variant="display1">REGISTER PATIENT</Typography>
                    <br />
                    <br />
                    <Typography variant="title">- About Me</Typography>
                    <br />
                    <FormControl className={classes.textField}>
                        <InputLabel>Title</InputLabel>
                        <NativeSelect
                            value={this.state.editPatient.title}
                            onChange={e => this.setState({title: e.target.value}) && this.handleChange.bind(this)}
                            input={<Input name="age" id="age-native-helper" />}
                        >  
                            <option value=""/>
                            <option value="Mr">Mr</option>
                            <option value="Mrs">Mrs</option>
                            <option value="Ms">Ms</option>
                            <option value="Dr">Dr</option>
                            <option value="Dr">Prof</option>
                        </NativeSelect>
                        {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.titleError}</FormHelperText> */}
                    </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="Firstname" 
                            name="firstName" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value={this.state.editPatient.firstname}
                            onChange={e => this.setState({firstname: e.target.value}) && this.handleChange.bind(this)}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.firstnameError}</FormHelperText> */}
                    </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="Lastname" 
                            name="lastname" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value = {this.state.editPatient.lastname}
                            // onChange={e => this.setState({lastname: e.target.value}) && this.handleChange.bind(this) && this.handleError}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error >{this.state.editPatient.lastnameError}</FormHelperText> */}
                        </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="number" 
                            label="Id Number" 
                            name="idNumber" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value = { this.state.editPatient.idNumber}
                            // onChange={e => this.setState({idNumber: e.target.value}) && this.handleChange.bind(this)}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error >{this.state.editPatient.idNumberError}</FormHelperText> */}
                    </FormControl>
                    
                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="Ocupation" 
                            name="ocuption" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value = { this.state.editPatient.ocupation }
                            // onChange={e => this.setState({ocupation: e.target.value}) && this.handleChange.bind(this)}
                            margin="normal"/>  
                        {/* <FormHelperText id="name-error-text" margin="dense" error= {true} >{this.state.editPatient.ocupationError}</FormHelperText> */}
                    </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="Employer" 
                            name="employer" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value = { this.state.editPatient.employer }
                            // onChange={e => this.setState({employer: e.target.value}) && this.handleChange.bind(this)}
                            margin="normal"/>  
                        {/* <FormHelperText id="name-error-text" margin="dense" error= {true} >{this.state.editPatient.employerError}</FormHelperText> */}
                    </FormControl>
                </div>


                    <br/><br/>


                <div className={classes.box}>
                    <Typography variant="title" >- Where Do I Live</Typography>
                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="Address" 
                            name="address" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value={this.state.editPatient.address}
                            // onChange={e => this.setState({address: e.target.value}) && this.handleChange.bind(this)}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.addressError}</FormHelperText> */}
                    </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="City" 
                            name="city" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value={this.state.editPatient.city}
                            // onChange={e => this.setState({city: e.target.value}) && this.handleChange.bind(this)}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.cityError}</FormHelperText> */}
                    </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="Suburb" 
                            name="surburb" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value = {this.state.editPatient.suburb}
                            // onChange={e => this.setState({suburb: e.target.value}) && this.handleChange.bind(this) && this.handleError}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error >{this.state.editPatient.suburbError}</FormHelperText> */}
                    </FormControl>
                
                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="Street" 
                            name="street" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value = { this.state.editPatient.street }
                            // onChange={e => this.setState({street: e.target.value}) &&  this.handleChange.bind(this)}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error >{this.state.editPatient.streetError}</FormHelperText> */}
                    </FormControl>
                </div>

                    <br/><br/>

                <div className={classes.box}> {/* My Contact Details */}
                    <Typography variant="title" >- My Contact Details</Typography>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="number" 
                            label="Cell No" 
                            name="cellNo" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value={this.state.editPatient.cellNumber}
                            // onChange={e => this.setState({cellNo: e.target.value}) && this.handleChange.bind(this)}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.cellNoError}</FormHelperText> */}
                    </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="number" 
                            label="Telephone" 
                            name="telephone" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value = {this.state.editPatient.telephone}
                            // onChange={e => this.setState({telephone: e.target.value}) && this.handleChange.bind(this) && this.handleError}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error >{this.state.editPatient.telephoneError}</FormHelperText> */}
                    </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="email" 
                            label="Email" 
                            name="email"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value = { this.state.editPatient.email }
                            // onChange={e => this.setState({email: e.target.value}) &&  this.handleChange.bind(this)}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error >{this.state.editPatient.emailError}</FormHelperText> */}
                    </FormControl>

                    <FormControl className={classes.textField}>
                        <TextField 
                            type="text" 
                            label="Postal Adress" 
                            name="postalAdress" 
                            InputLabelProps={{
                                shrink: true,
                            }}
                            value={this.state.editPatient.postalAdress}
                            // onChange={e => this.setState({postalAdress: e.target.value}) && this.handleChange.bind(this)}
                            margin="normal"/>
                        {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.postalAdressError}</FormHelperText> */}
                    </FormControl>
                </div>

                <br/><br/>

                <div className={classes.box}> {/* My Contact Details */}
                    <Typography variant="title" >- Who is responsible for payment</Typography>
                    
                    <TextField 
                        type="text" 
                        label="medical Scheme" 
                        name="medicalScheme" 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={this.state.editPatient.medicalScheme}
                        className={classes.textField} 
                        // onChange={e => this.setState({medicalScheme: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.medicalSchemeError}</FormHelperText> */}

                    <TextField 
                        type="number" 
                        label="Member number" 
                        name="memberNumber " 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value = {this.state.editPatient.memberNo}
                        className={classes.textField} 
                        // onChange={e => this.setState({memberNo: e.target.value}) && this.handleChange.bind(this) && this.handleError}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error >{this.state.editPatient.memberNoError}</FormHelperText> */}
                
                    <TextField 
                        type="text" 
                        label="Principle Member" 
                        name="principleMember" 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={this.state.editPatient.principleMember}
                        className={classes.textField} 
                        // onChange={e => this.setState({principleMember: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.principleMemberError}</FormHelperText> */}

                    <TextField 
                        type="text" 
                        label="First Name" 
                        name="payerName" 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={this.state.editPatient.payerName}
                        className={classes.textField} 
                        // onChange={e => this.setState({payerName: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.payerNameError}</FormHelperText> */}

                    <TextField 
                        type="text" 
                        label="Last Name" 
                        name="lastName" 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={this.state.editPatient.payerSurname}
                        className={classes.textField} 
                        // onChange={e => this.setState({payerSurname: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.payerSurnameError}</FormHelperText> */}

                </div>

                <br/><br/>

                <div className={classes.box}> {/* My Contact Details */}
                    <Typography variant="title" >- Contact Details of Payer</Typography>
                    
                    <TextField 
                        type="text" 
                        label="Address" 
                        name="medicalPayerAddress" 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={this.state.editPatient.medicalPayerAddress}
                        className={classes.textField} 
                        // onChange={e => this.setState({medicalPayerAddress: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.medicalPayerAddressError}</FormHelperText> */}

                    <TextField 
                        type="text" 
                        label="City" 
                        name="medicalPayerCity" 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value = {this.state.editPatient.medicalPayerCity}
                        className={classes.textField} 
                        // onChange={e => this.setState({medicalPayerCity: e.target.value}) && this.handleChange.bind(this) && this.handleError}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error >{this.state.editPatient.medicalPayerCityError}</FormHelperText> */}
                
                    <TextField 
                        type="text" 
                        label="Suburb" 
                        name="medicalPayerSuburb" 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={this.state.editPatient.medicalPayerSuburb}
                        className={classes.textField} 
                        // onChange={e => this.setState({medicalPayerSuburb: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.medicalPayerSuburbError}</FormHelperText> */}

                    <TextField 
                        type="text" 
                        label="Street" 
                        name="medicalPayerStreet" 
                        InputLabelProps={{
                            shrink: true,
                        }}
                        value={this.state.editPatient.medicalPayerStreet}
                        className={classes.textField} 
                        // onChange={e => this.setState({medicalPayerStreet: e.target.value}) && this.handleChange.bind(this)}
                        margin="normal"/>
                    {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.medicalPayerStreetError}</FormHelperText> */}

                    <FormControl className={classes.textField}>
                    <InputLabel>Gap Cover</InputLabel>
                    <NativeSelect
                        value={this.state.editPatient.gapCover}
                        // onChange={e => this.setState({gapCover: e.target.value}) && this.handleChange.bind(this)}
                        input={<Input name="gapCover" id="gapCover" />}   
                    >  
                        <option value=""/>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </NativeSelect>
                    {/* <FormHelperText id="name-error-text" margin="dense" error>{this.state.editPatient.gapCoverError}</FormHelperText> */}
                    </FormControl>
                </div>

                <br/><br/>

                <div className={classes.box}>
                    <Tooltip title="Add new Patient">
                        <Button variant="contained"  aria-label="Add" type="submit" margin="normal" className={classes.btnLeft} >Add </Button>
                    </Tooltip>
                    <Tooltip title="Clear form">
                        <Button variant="contained" onReset={this.resetForm} type="reset" margin="normal" className={classes.absolute}>
                        Clear
                        </Button>
                    </Tooltip>
                </div>
                <br />
                <br />
                <div className={classes.appFrame}>
                    <Snackbar
                        // open={open}
                        autoHideDuration={4000}
                        onClose={this.handleClose}
                        ContentProps={{
                        'aria-describedby': 'snackbar-fab-message-id',
                        // style:{backgroundColor: bgColor}
                        }}
                        variant="success"
                        message={<span id="snackbar-fab-message-id">{this.state.editPatient.message}</span>}
                        action={
                        <IconButton className="cornerBtn" onClick={this.handleClose}>
                            <CloseIcon/>
                        </IconButton>
                        }
                        className={classes.snackbar}
                    />
                </div>
            </form>

        )
    }
}


export default withStyles(styles, { withTheme: true })(EditPatient)







