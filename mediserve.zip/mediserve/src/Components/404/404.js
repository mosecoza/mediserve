import React from 'react'
import '../../App.css'
const NotFound = () => {

    return(
        <div className="App">
            <h1 className="err_code">404</h1>
            <p>Error</p>
            <h1>:(</h1> 
            <h2>It seems that the page you are looking for does not exist</h2>
        </div>
    )
}

export default NotFound