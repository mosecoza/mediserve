import React, { Component, Fragment } from 'react';
import { withStyles } from '@material-ui/core/styles';

import Typography from '@material-ui/core/Typography'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';


const styles = theme => ({
  root: {
    flexGrow: 1,
    // height: 430,
    zIndex: 1,
    overflow: 'hidden',
    position: 'relative',
    display: 'flex',
    width: '100%',
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 500,
  },
});


class Patients extends Component {

  state = {
    fields: {
      firstname: '',
      lastname: '',
      email: '',
      dob: ''
    },
    mobileOpen: false,
    Patients:[],
    Shakespear:[],
    movies:[]
  };


  componentDidMount() {

    fetch('http://localhost:9200/patients/_search?pretty').then(res=> res.json()).then(patients => this.setState({Patients: patients.hits.hits}))
    .catch(function(error) {
      console.log("unable to find "+error);
    });

  }

  render() {
    const { classes } = this.props;
    


    return(
      <Fragment>
        {/* <Paper>Search</Paper> */}
        <Typography variant="title" id="tableTitle">
            Patients

            
        </Typography>
 
        <Paper className={classes.root} >
          <Table className={classes.table}>
            <TableHead>
              <TableRow>
                <TableCell>UserId</TableCell>
                <TableCell>First Name</TableCell>
                <TableCell>Last Name</TableCell>
                <TableCell>Email</TableCell>
                <TableCell>DOB</TableCell>
                <TableCell>Gender</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {this.state.Patients.map(patient=>{
              return(
                <TableRow key={patient._id}>
                  <TableCell component="th" scope="row">{patient._source.id}</TableCell>
                  <TableCell>{patient._source.firstName}</TableCell>
                  <TableCell>{patient._source.lastname}</TableCell>
                  <TableCell>{patient._source.email}</TableCell>
                  <TableCell>{patient._source.dob}</TableCell>
                  <TableCell>{patient._source.gender}</TableCell>
                </TableRow>
              )
            })}
            </TableBody>
          </Table>
        </Paper>
      </Fragment>


        
    )
    
  }
}

export default withStyles(styles, { withTheme: true })(Patients);
