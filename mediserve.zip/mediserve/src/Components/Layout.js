import React, { Component, Fragment } from 'react';
import { withStyles } from '@material-ui/core/styles';
import {
  AppBar,
  Toolbar, 
  Typography, 
  CssBaseline, Tab, Tabs, 
}from '@material-ui/core';
import red from '@material-ui/core/colors/red';
import PhoneIcon from '@material-ui/icons/Phone';
import classNames from 'classnames';
import Icon from '@material-ui/core/Icon';
import FavoriteIcon from '@material-ui/icons/Favorite';
import PersonPinIcon from '@material-ui/icons/PersonPin';
import HelpIcon from '@material-ui/icons/Help';
import ShoppingBasket from '@material-ui/icons/ShoppingBasket';
import ThumbDown from '@material-ui/icons/ThumbDown';
import ThumbUp from '@material-ui/icons/ThumbUp';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';
import { Link,withRouter } from 'react-router-dom'
import { compose } from 'recompose';
import Register from './Register/Register' 
import './../App.css'
// import Reg from './Register/Reg'




const styles = theme =>({
  root: {
    flexGrow: 1,
  },
  flex: {
    flexGrow: 1,
  },
  floatBtn:{
    zIndex: 999999998,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  content:{
    padding: 100,
    paddingTop: 80
  }
});


class App extends Component {

  state = {
    fields: {
      firstname: '',
      lastname: '',
      email: '',
      dob: ''
    },
    mobileOpen: false,
    Patients:[],
    showMe:false,
  };



  handleDrawerToggle = () => { //Toogler for mobie size window
    this.setState(state => ({ mobileOpen: !state.mobileOpen }));
  };

  togglePatientsForm = () => {
    this.setState({
      showMe:!this.state.showMe,
    })
  }

  onSubmit = fields=>{
    console.log('App component got : ', fields)
    this.setState({ fields })
  }

  render() {
    const { classes,location: {pathname}, theme ,children} = this.props;

    return(
      <Fragment>
        <CssBaseline />
          <div style={{marginBottom:54}}  >
            <AppBar position="fixed" >
            <Tabs
              // value={value}
              onChange={this.handleChange}
              scrollable
              scrollButtons="on"
            ><Typography variant="title" className={classes.flex}>
            MediServe
          </Typography>
              <Tab label=" New Patient"  onClick={this.togglePatientsForm} icon={<AddIcon />} ></Tab>
              <Tab label="Settings" icon={<ThumbUp />} />
            </Tabs>
              {/* <Toolbar>
                
                
              </Toolbar> */}
            </AppBar>
          </div>

          {/* <main > */}
          
              {children}
        {/* </main> */}

        {
          this.state.showMe?
          <div >
            <div className="overLayerTop" onClick={this.togglePatientsForm}/>
            
            <Register />
          </div>
          :null
        }
        
      </Fragment>
    )
    
  }
}

export default compose(
  withRouter,
  withStyles(styles, { withTheme: true })
)(App);