import React from 'react'
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types'
import {Paper, Typography, Button} from '@material-ui/core'
import Call from '@material-ui/icons/Call'
import Address from '@material-ui/icons/LocationOn'
import Person from '@material-ui/icons/Person'
import Edit from '@material-ui/icons/Create'
import Close from '@material-ui/icons/Close'

import './style.css'

const styles = theme => ({
    root: {
        [theme.breakpoints.up('lg')]:{
            flexGrow: 1,
            padding: '100px',
            marginBottom: 10,
            width: '100%',
            // margin: '0 auto',
        },
        [theme.breakpoints.down('md')]:{
            flexGrow: 1,
            padding: '50px',
            marginBottom: 10,
            width: '100%',
        },
        [theme.breakpoints.down('sm')]:{
            width:'100%',
            padding:"50px",
        },
        [theme.breakpoints.down('xs')]:{
            width:'100%',
            padding:"40px",
            margin: "10px auto",
            paddingLeft:"20px",
            paddingRight:"20px",
        }
    },
    header:{
        [theme.breakpoints.up('xl')]:{
            width:"90%",
            paddingTop: "40px",
            paddingLeft:"20px",
            paddingRight:"20px",
        },
        [theme.breakpoints.down('lg')]:{
            width:"90%",
            margin: "0 auto",
            paddingTop: 40,
            // marginLeft: 40,
            // display:"inline-block"
        },
        [theme.breakpoints.down('md')]:{
            width:"100%",
            margin: "0 auto",
            paddingTop: 40,
            // marginLeft: 40,
            // display:"inline-block"
        },
        [theme.breakpoints.down('md')]:{
            width:"100%",
            margin: "0 auto",
            paddingTop: 40,
            // marginLeft: 40,
            // display:"inline-block"
        }

    },
    headerIco:{
        [theme.breakpoints.up('xl')]:{
            display:"inline-block",
            float:"left",
            fontSize: "40px",
        },
        [theme.breakpoints.down('lg')]:{
            display:"inline-block",
            float:"left",
            fontSize: "40px",
        },
    },
    heading: {
        [theme.breakpoints.up('xl')]:{
            flexGrow: 1,
            width: '100%',
            // padding: 5,
            borderBottom: "1px solid black",
            marginLeft: 50,
        },
        [theme.breakpoints.down('lg')]:{
            flexGrow: 1,
            width: '75%',
            // padding: 5,
            borderBottom: "1px solid black",
            marginLeft: 50,
        }
        
    },
    editBtn: {
        position: 'absolute',
        right:0
    },
    // braker:{
    //     width: "0%",
    //     padding:5,
    //     display: "block",
    //     margin: "5px",
    //     // backgroundColor: "silver"
    // },
    spacer:{
        width: "10%",
        padding:5,
        display: "block",
        margin: "5px",
        // backgroundColor: "silver"
    },
    label:{
        [theme.breakpoints.up('xl')]:{
            display:"block",
            width: "250px",
        // marginRight: "50px"
        },
        [theme.breakpoints.up('lg')]:{
            display:"block",
            width: "100px",
        // marginRight: "50px"
        },
        [theme.breakpoints.up('md')]:{
            display:"block",
            width: "80px",
        // marginRight: "50px"
        },
        [theme.breakpoints.up('sm')]:{
            display:"block",
            width: "100%",
        // marginRight: "50px"
        },
        [theme.breakpoints.up('xs')]:{
            display:"block",
            width: "100%",
        // marginRight: "50px"
        },
    },
    data:{
        [theme.breakpoints.up('xl')]:{
            // paddingLeft: "200px",
            // paddingTop: "20px",
            // paddingBottom: "20px",
            width: "80%",
            margin: "0 auto",
        },
        [theme.breakpoints.up('lg')]:{
            // paddingLeft: "100px",
            // paddingTop: "20px",
            // paddingBottom: "20px",
            width: "80%",
            margin: "0 auto",
        },
        [theme.breakpoints.down('md')]:{
            // paddingLeft:"100px",
            width: "85%",
            margin: "0 auto",
        },
        [theme.breakpoints.down('sm')]:{
            // paddingLeft:"80px",
            width: "80%",
            margin: "0 auto",
        },
        [theme.breakpoints.down('xs')]:{
            // paddingLeft:"70px",
            width: "90%",
            margin: "0 auto",
        }
    },
    btnsBlock:{
        width: "100%",
        paddingTop:"50px",
        paddingBottom:"40px",
    },
    btns:{
        [theme.breakpoints.up('xl')]:{
            float:"right",
        },
        [theme.breakpoints.down('lg')]:{
            float:"unset",
        },
    },
    btn:{
        minWidth:"150px",
        marginRight: 40,
        [theme.breakpoints.down('md')]:{
            minWidth:"150px",
            margin: 10
        }
    },
    Res:{
        [theme.breakpoints.up('xl')]:{
            paddingLeft: 50
        },
        [theme.breakpoints.down('lg')]:{
            paddingLeft: 30
        },
        [theme.breakpoints.down('md')]:{
            paddingLeft: 30
        },
        [theme.breakpoints.down('sm')]:{
            paddingLeft: 10
        },
        [theme.breakpoints.down('xs')]:{
            paddingLeft: 0
        }
    },
    colon:{
        paddingLeft:'20px',
    }
  });

 

const Patient = (props) => { 
    
    const { classes } = props;

     return(
         <div className="patientInfor">
            <div className="showPatient">
                <Paper className={classes.root}>
                    <Typography className={classes.flex} variant="display1">{props.patient.firstname}  {props.patient.lastname}</Typography>


                    <div className={classes.data}>
                        <p>
                            <label className="label">Name</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.firstname}</span>
                        </p>
                        <p>
                            <label className="label">Lastname</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.lastname}</span>
                        </p>
                        <p>
                            <label className="label">Id Number</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.idNumber}</span>
                        </p>
                        <p>
                            <label className="label">Occupation</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.ocupation}</span>
                        </p>
                        <p>
                            <label className="label">Employee</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.employer}</span>
                        </p>
                    </div>

                    <span className={classes.braker}/>

                    <div className={classes.header}>
                        <Address className={classes.headerIco}/> 
                        <Typography className={classes.heading} variant="headline">My Address </Typography>
                    </div>
                    <div className={classes.data}>
                        <p>
                            <label className="label">City</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.city}</span>
                        </p>
                        <p>
                            <label className="label">Suburb</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.suburb}</span>
                        </p>
                        <p>
                            <label className="label">Street</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.street}</span>
                        </p>

                    </div>

                    <span className={classes.braker}/>

                    <div className={classes.header}>
                        <Call className={classes.headerIco}/> 
                        <Typography className={classes.heading} variant="headline">My Contact Details</Typography>
                    </div>
                    <div className={classes.data}>
                        <p>
                            <label className="label">Cell Number</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.cellNumber}</span>
                        </p>
                        <p>
                            <label className="label">Telephone</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.telephone}</span>
                        </p>
                        <p>
                            <label className="label">Email</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.email}</span>
                        </p>
                        <p>
                            <label className="label">Postal Address</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.address}</span>
                        </p>
                    </div>

                    <span className={classes.braker}/>
                </Paper>
                
                <Paper className={classes.root}>
                    <Typography className={classes.flex} variant="display1">Who is Responsible For Payment</Typography>
                    <span className={classes.braker}/>
                    <div className={classes.header}>
                        <Person className={classes.headerIco}/> 
                        <Typography className={classes.heading} variant="headline">About Payer</Typography>
                    </div>
                    <span className={classes.braker}/>
                    <div className={classes.data}>
                        <p>
                            <label className="label">Medical Scheme</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.medicalScheme}</span>
                        </p>
                        <p>
                            <label className="label">Member No</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.memberNo}</span>
                        </p>
                        <p>
                            <label className="label">Prinsiple member</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.principleMember}</span>
                        </p>
                        <p>
                            <label className="label">Firstname</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.payerName}</span>
                        </p>
                        <p>
                            <label className="label">Lastname</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.payerSurname}</span>
                        </p>
                    </div>
                    <div className={classes.header}>
                        <Address className={classes.headerIco}/> 
                        <Typography className={classes.heading} variant="headline"> Address </Typography>
                    </div>
                    <div className={classes.data}>
                        <p>
                            <label className="label">City</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.medicalPayerCity}</span>
                        </p>
                        <p>
                            <label className="label">Suburb</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.suburb}</span>
                        </p>
                        <p>
                            <label className="label">Street number</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res}>{props.patient.medicalPayerStreet}</span>
                        </p>
                    </div>
                    <span className={classes.braker}/>
                    <div className={classes.header}>
                        <Call className={classes.headerIco}/> 
                        <Typography className={classes.heading} variant="headline">Contact Details</Typography>
                    </div>
                    <span className={classes.braker}/>
                    <div className={classes.data}>
                        <p>
                            <label className="label">Cell Number</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.payerCell}</span>
                        </p>
                        <p>
                            <label className="label">Telephone</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.payerTel}</span>
                        </p>
                        <p>
                            <label className="label">Email</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.payerEmail}</span>
                        </p>
                        <p>
                            <label className="label">Postal Address</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.medicalPayerAddress}</span>
                        </p>
                        <p>
                            <label className="label">Gap Cover</label> 
                            <span className={classes.colon}>:</span> 
                            <span className={classes.Res} >{props.patient.gapCover}</span>
                        </p>
                    </div>
                    <div className={classes.btnsBlock}>
                        <div className={classes.btns}>
                            <Button 
                                variant="contained" 
                                size="large" 
                                onClick={props.onSubmit} 
                                className={classes.btn} 
                                color="default">
                                <Edit/>
                                Edit
                            </Button> 
                            {/* <div className={classes.spacer}/> */}
                            <Button 
                                variant="contained" 
                                size="large" 
                                onClick={props.onClick}
                                className={classes.btn} 
                                color="secondary">
                                <Close/> 
                                Close
                            </Button>
                        </div>
                    </div>
                </Paper>
            </div>
        </div>
     )
}

Patient.propTypes = {
    classes: PropTypes.object.isRequired,
  };

export default withStyles(styles)(Patient)