import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import {Paper,Card, Tooltip, TextField, Typography} from '@material-ui/core';
import PaginationActions from '@material-ui/core/TablePaginationActions'
import Button from '@material-ui/core/Button';
import Chip from '@material-ui/core/Chip'
import Avatar from '@material-ui/core/Avatar';
import SearchIcon from '@material-ui/icons/Search';
import DoneIcon from '@material-ui/icons/Done';
import Highlighter from "react-highlight-words";
import { Link,withRouter } from 'react-router-dom';
import CardActions from '@material-ui/core/CardActions';
import "./../../App.css"
import axios from 'axios';
 import Update from "./Update";
 import Patient from "./Patient";




const styles = theme => ({
  root: {
    ...theme.mixins.gutters(),
    width: '100%',
    marginTop: theme.spacing.unit * 1,
    overflowX: 'hidden',
    overflowY: 'hidden',
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 1,
    borderRadius: 0,
    boxShadow: ' 0px 1px 5px 1px rgba(0,0,0,0.2)',
    textAlign: "center",
  },
  textField:{
    width: 475,
    backgroundColor: "white",
    borderRadius:4,
    position: 'inline-block'
    // border: "1px solid black",
  },
    
  // showPatientCss:{
  //   position: "absolute",
  //   zIndex: 9999,
  //   backgroundColor: "teal",
  // },
 
  results:{
    marginBottom: 25,
    padding: 15,
    width: 500
  },

  noOfResults:{
    position: 'inline-block'
  },
  spacer:{
    padding: "10px",
  },



});
const actionsStyles = theme => ({
  root: {
    flexShrink: 0,
    color: theme.palette.text.secondary,
    marginLeft: theme.spacing.unit * 1,
    // boxShadow:' 0px 1px 5px 1px rgba(0,0,0,0.1)',
    // paddingBottom:1
  },
});
const rrt = [];

class PatientsList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {

      selected: [],
      patients: [],
      returnPatient: [],
      viewPatient: [],
      page: 0,
      shards: [],
      rowsPerPage: 10,
      search:'',
      userId: '',
      patientId: '',
      open: false,
      showPatientInfor: false,
      showUpdate: false,
      total: '',
      style: "results",
      searchPhrases1: '',
      searchPhrases2: '',
      searchPhrases3: '',

      toggleInput2: false,
      toggleInput3: false,
    };
    // this.sortBy = this.sortBy.bind(this)
  }

  
  componentDidMount() {
    
    
  // componentDidUpdate() {
    axios.get('http://localhost:9200/patientsdata/patient/_search?pretty')
      .then(res => {
        
          
          this.setState({patients: res.data.hits.hits})
        
        
        this.setState({patients: res.data.hits.hits})
      })
      // .then(res => this.setState({data: res.data}))
      
    .catch(function (error){
        if(error.res){
            // The request was made and the server responded with a status code
            // that falls out of the range of 2xx
            console.log("Patient Error : "+error.res.patients);
            console.log("Status Error : "+error.res.status);
            console.log("Header Error : "+error.res.headers);
        }else if(error.request){
            // `error.request` is an instance of XMLHttpRequest in the browser and an instance of http.ClientRequest
            console.log("Request Error : "+error.request);
        }else {
            console.log('Error Message'+ error.message)
        }
    })
  }

  

  deleteHandler =(fields) =>{
    fields = this.state.patientId
    console.log('Its working '+fields)
    // let uri = 'http://localhost:9200/patientsdata/patient'
    // axios.delete(uri+'/'+deleteUser)
    // .then(res=> {
    //   console.log("Sucess"+ res)
    //   // this.componentDidMount()
    // })
    this.setState({ open: false });
  }
  
  handleDeletePopUp = (event) => {
    this.setState({ open: true });
    console.log(event)
    this.setState({userId: event})
  };

  viewPatientHandler =(event) =>{
    let patientSelect = event
    this.setState({patientId: patientSelect})
    console.log("Editing  " +patientSelect)

    let uri = 'http://localhost:9200/patientsdata/patient'
    axios.get(uri+'/'+patientSelect)
    .then(res => {
      this.setState({patientId: res.data._id}),
      this.setState({viewPatient: res.data._source})
      console.log("Got Patient"+ JSON.stringify(this.state.viewPatient))
    })
    this.toggleView()
    return patientSelect
  }

  toggleView = () =>{
    this.setState({showPatientInfor:!this.state.showPatientInfor})

  }

  EditPatient = fields =>{
    this.toggleView()
    fields = this.state.patientId
    console.log('Its working '+fields)
    this.toggleUpdate()
  }

  toggleUpdate = () => {
    this.setState({showUpdate: !this.state.showUpdate})
  }


  handleChangePage = (event, page) => {
    this.setState({ page });
  };


  handleChangeRowsPerPage = event => {
    this.setState({ rowsPerPage: event.target.value });
  };

  handleSearch = (event) => {

    

    let searchString = this.state.search.trim();
    searchString = searchString.toLocaleLowerCase();
    

    let mustQuery = [];
    let searchPhrases = searchString.split(" ");
    searchPhrases.forEach(phrase => {
      
       let text = phrase.trim();
       let phased = searchPhrases;
       if (text.length > 0){
        this.setState({searchPhrases1: phased[0]})
        this.setState({searchPhrases2: phased[1]})
        this.setState({searchPhrases3: phased[2]})


          mustQuery.push({
            wildcard: {
              "firstname": {
                "value": `*${text}*`
              }
            }
          })
       }
    })

// Search query for Elastic 
    this.setState({search: event.target.value.substr(0,50)})
    
    axios.post('http://localhost:9200/patientsdata/patient/_search',{
       
        "query":{
          "bool": {
          "should": mustQuery
            }
        }
      
    })
    .then(res => {
      
      
      this.setState({returnPatient: res.data.hits.hits});
      this.setState({total: res.data.hits});
      this.setState({open: true})
      console.log(res.data.hits.hits);
      
      if(this.state.search.length ===0){
        this.setState({open: false})
      }
    }).catch(error => console.log("err: "+error.message));


  }

  handleDelete = () =>{
    console.log("delelted")
  }

  handleClose = () => {
    this.setState({ open: false });
  };

 
render(){
  let filteredPatients;
  
      
  if(this.state.search.length !== 0){

    


    filteredPatients = this.state.returnPatient;
    // forEach.filteredPatients

    const doubled = filteredPatients.map((number) => 

        Object.values(number._source).indexOf("personal") 
        ?
              console.log(number._source.personal + "\n"+ number._source.contacts + "\n"+ number._source.medical)
        :console.log("eish")

      );
    
    console.log("Searchin...")
    
    
  }
  else if(this.state.search.length === 0){
    filteredPatients = this.state.patients
    console.log("not Searching")
    
  }
  const { classes } = this.props;
  

  return (
    <div className="">
      <div>
        <Tooltip title="Search For a patient and press Enter">
          <div>
            <SearchIcon className={classes.ico}/>
              <TextField
                id="search"
                label="Search"
                type="search"
                className={classes.textField}
                value={this.state.search}
                margin="normal" 
                onChange={this.handleSearch.bind(this)}
              />
            </div>
        </Tooltip>

          
          {
            this.state.open?
            <div>
              
              <Chip label={this.state.searchPhrases1} className={classes.chip} />
                <span className={classes.spacer}/>
              {/* {this.state.toggleInput2? */}
              {/* <Chip label={this.state.searchText2} className={classes.chip} /> */}
              <Chip
                label={this.state.searchPhrases2}
                clickable
                className={classes.chip}
                color="primary"
              />
              <span className={classes.spacer}/>
              <Chip label={this.state.searchPhrases3} className={classes.chip} />
              <Typography className={classes.noOfResults}>Number of Matching Results : {this.state.total.total}</Typography>
            </div>
            :null
          } 
      </div>
      
      <div className={classes.header}>
        <br />
      </div>
      <br />
      <br />
      
      
      {
        filteredPatients
        .map((patient) =>    
        
          <Card className={classes.results}  > 
            <Typography 
            variant="title" 
            className="patientLink" 
            color="primary" 
            
            key={patient._id} onClick={() =>this.viewPatientHandler(patient._id)}
            >
            
            {patient._source.firstname} {patient._source.lastname} 
            </Typography >
            <Typography>Id Number : {patient._source.idNumber}</Typography>
            <Typography>Email Address: {patient._source.email}</Typography>
            <Typography>Cell :{patient._source.cellNumber}</Typography>
            <CardActions>
              <Button onClick={patientId =>this.EditPatient(patientId)} size="small" color="primary">
                Edit
              </Button>
              <Button onClick={field =>this.deleteHandler(field)} size="small" color="primary">
                Delete
              </Button>
            </CardActions>
          </Card>
        )
      },

      {
        this.state.showPatientInfor?
        <Patient
          onSubmit={patientId =>this.EditPatient(patientId)}
          onClick={field =>this.deleteHandler(field)}
          patient= {this.state.viewPatient}
          onClick={this.toggleView}
        />
        :null
      }
      
      {
        this.state.showPatientInfor?
          <div className="overLayer" onClick={this.toggleView}/>
        :null
      }

      {
        this.state.showUpdate?
        <Update 
        patientData={this.state.viewPatient} 
        id={this.state.patientId}
        // onClick={()=>this.toggleUpdate()}
        />
        :null
      }

      {
        this.state.showUpdate?
          <div className="overLayer" onClick={this.toggleUpdate}/>
        :null
      }
        
  </div>
  );
}
  
}


export default withStyles(styles)(PatientsList);


const PaginationActionsWrapped = withStyles(actionsStyles,{ withTheme: true })(
  PaginationActions,Paper
);