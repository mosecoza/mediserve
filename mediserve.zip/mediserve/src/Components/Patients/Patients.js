import React, { Component, Fragment } from 'react';
import { withStyles } from '@material-ui/core/styles';
// import axios from 'axios'

import Typography from '@material-ui/core/Typography'
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';


const styles = theme => ({
  root: {
    flexGrow: 1,
    // height: 430,
    zIndex: 1,
    overflow: 'hidden',
    position: 'relative',
    display: 'flex',
    width: '100%',
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 500,
  },
});


class Patients extends Component {

  state = {
    fields: {
      firstname: '',
      lastname: '',
      email: '',
      dob: ''
    },
    mobileOpen: false,
    Patients:[],
    Shakespear:[],
    movies:[]
  };


  componentDidMount() {

 

    fetch('http://localhost:9200/patients/patient/_search')
    .then(res=> res.json())
    .then(patients => this.setState({Patients: patients.hits.hits}))

    .catch(function(error) {
      console.log("unable to find "+error);
    });
    
  }

  render() {
    const { classes } = this.props;
    


    return(
      <Fragment>
        {/* <Paper>Search</Paper> */}
        <Typography variant="title" id="tableTitle">
            Patients 
        </Typography>
        <TextField
          id="search"
          label="Search Patient"
          type="search"
          className={classes.textField}
          margin="normal"
        />
        <Paper className={classes.root} >
          <Table className={classes.table}>
            <TableHead>
              <TableRow>
                <TableCell>UserId</TableCell>
                <TableCell>First Name</TableCell>
                <TableCell>Last Name</TableCell>
                <TableCell>Email</TableCell>
                <TableCell>DOB</TableCell>
                <TableCell>Gender</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {this.state.Patients.map(patient=>{
              return(
                <TableRow key={patient._id}>
                  <TableCell component="th" scope="row">{patient._source.id}</TableCell>
                  <TableCell>{patient._source.firstName}</TableCell>
                  <TableCell>{patient._source.lastname}</TableCell>
                  <TableCell>{patient._source.email}</TableCell>
                  <TableCell>{patient._source.dob}</TableCell>
                  <TableCell>{patient._source.gender}</TableCell>
                </TableRow>
              )
            })}
            </TableBody>
          </Table>
        </Paper>
      </Fragment>


        
    )
    
  }
}

export default withStyles(styles, { withTheme: true })(Patients);
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------
// -----------------------------------------------------------------------------------------------------------------------------


import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import Icon from '@material-ui/core/Icon';
import Tooltip from '@material-ui/core/Tooltip';
import DeleteIcon from '@material-ui/icons/Delete';
import TextField from '@material-ui/core/TextField'
import axios from 'axios'
import './../../App.css'
import Patients from '../Patients copy/Patients';
let counter = 0;




const styles = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 1200,
  },
});


class EnhancedTable extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      order: 'asc',
      orderBy: 'firstName',
      selected: [],
      patients: [],
      page: 0,
      rowsPerPage: 15,
      search:'',
    };
  }


  

    componentDidMount() {
      axios.get('http://localhost:9200/patients/patient/_search?pretty&size=40')
        // .then(res=> console.log(res))
        .then(res => this.setState({patients: res.data.hits.hits}))
        // .then(res => this.setState({data: res.data}))
      .catch(function (error){
          if(error.res){
              // The request was made and the server responded with a status code
              // that falls out of the range of 2xx
              console.log(error.res.patients);
              console.log(error.res.status);
              console.log(error.res.headers);
          }else if(error.request){
              // `error.request` is an instance of XMLHttpRequest in the browser and an instance of http.ClientRequest
              console.log(error.request);
          }else {
              console.log('Error', error.message)
          }
      })
       
    }
 
  

  render() {


    const { classes } = this.props;
    const { patients, order, orderBy, selected, rowsPerPage, page } = this.state;
    const emptyRows = rowsPerPage - Math.min(rowsPerPage, patients.length - page * rowsPerPage);

    return (
      <Paper className={classes.root}>
      <Tooltip title="Search For a patient and press Enter">
        <TextField
          id="search"
          label="Search Patient"
          type="search"
          className={classes.textField}
          margin="normal"
          // value= {this.state.search}
          value= {this.state.search}
          // onChange={this.updateSearch.bind(this)}
        />
        </Tooltip>
        <Paper className="patientPaper" elevation={1}>
          <Grid container spacing={24}>
            <Grid item xs={2} variant="headline"> firstName </Grid>
            <Grid item xs={2}>lastname</Grid>
            <Grid item xs={2}>Email</Grid>
            <Grid item xs={2}>Date of Birth</Grid>
            <Grid item xs={2}><Icon class="material-icons" variant="headline">Edit</Icon></Grid>
            <Grid item xs={2}>Delete</Grid>
            <br/>
            <br/>
          </Grid>   
        </Paper>

        {patients.map(patient => {
          return (
            <div>
              <Paper className="patientPaper" key={patient._source.id} elevation={1}>
                <Grid container spacing={24}>
                  <Grid item xs={2} variant="headline"> {patient._source.firstName} </Grid>
                  <Grid item xs={2}>{patient._source.lastname}</Grid>
                  <Grid item xs={2}>{patient._source.email}</Grid>
                  <Grid item xs={2}>{patient._source.dob}</Grid>
                  <Grid item xs={2}><Icon class="material-icons" variant="headline">Edit</Icon></Grid>
                  <Grid item xs={2}><DeleteIcon/></Grid>
                </Grid>   
              </Paper>
              <br/>
            </div>
          );
        })}

        
      </Paper>
    )
  }
}

EnhancedTable.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(EnhancedTable);