import React from 'react'
import PropTypes from 'prop-types'
import {Paper, Typography, Grid, Button,IconButton} from '@material-ui/core'
import Edit from '@material-ui/icons/Create';
import Face from '@material-ui/icons/Face'
import '../../App.css'

const ViewPatients = (props) => {

    const styles = theme =>({
        root: {
            ...theme.mixins.gutters(),
            width: '100%',
            marginTop: theme.spacing.unit * 1,
            overflowX: 'hidden',
            overflowY: 'hidden',
            paddingTop: theme.spacing.unit * 2,
            paddingBottom: theme.spacing.unit * 1,
            borderRadius: 0,
            boxShadow: ' 0px 1px 5px 1px rgba(0,0,0,0.2)',
            textAlign: "center",
        },
        grid:{
            padding: 50
        },
        button: {
            margin: theme.spacing.unit,
            display: "inline-block",
            float: 'left'
        },
        extendedIcon:{
            marginRight: theme.spacing.unit,
        },
    })



    return(



        <div className="pop">
            <Grid container spacing={8}>
                <Grid item xs={12} sm={12}>
                    <Paper className="grid">
                        <Typography variant="display1"><Face />{props.name} {props.surname}</Typography>   
                        <Button variant="extendedFab" aria-label="Delete" className={styles.button}>
                            <Edit className={styles.extendedIcon} />
                            Edit Patient 
                        </Button>
                    </Paper> 
                    {/* <Paper> */}
                </Grid>
                   
                    <Grid  item xs={12} sm={12} md={6}>
                        <Paper className="patientData"> 
                            <Typography className="title" variant="title">About Me</Typography>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Name</label> <br />
                                    <span> &nbsp;-{props.title} {props.name} {props.surname}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Id Number</label> <br />
                                    <span> &nbsp;-{props.idNo}</span>
                                </p>
                                </Grid>
                            </Grid>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Occupation</label> <br />
                                    <span> &nbsp;-{props.ocupation}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Employer</label> <br />
                                    <span> &nbsp;-{props.employer}</span>
                                </p>
                                </Grid>
                            </Grid>
                            <div className="braker" />
                            
                            {/* ___________________________________________________________________________ */}
                            <Typography className="title" variant="title">Where Do I live</Typography>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">City</label> <br />
                                    <span> &nbsp;-{props.city}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Suburb</label> <br />
                                    <span> &nbsp;-{props.suburb}</span>
                                </p>
                                </Grid>
                            </Grid>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Street</label> <br />
                                    <span> &nbsp;-{props.street}</span>
                                </p>
                                </Grid>
                                {/* <Grid item xs={6} sm={6}><p>
                                    <label className="label">Employer</label> <br />
                                    <span> &nbsp;-{props.occupation}</span>
                                </p>
                                </Grid> */}
                            </Grid>


                            <div className="braker" />

                            
                            {/* _____________________     ______________________________________________________ */}
                            <Typography className="title" variant="title">My Contact Details</Typography>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Cell Number</label> <br />
                                    <span> &nbsp;-{props.cell}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Telephone Number</label> <br />
                                    <span> &nbsp;-{props.telephone}</span>
                                </p>
                                </Grid>
                            </Grid>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Email</label> <br />
                                    <span> &nbsp;-{props.email}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Postal Address</label> <br />
                                    <span> &nbsp;-{props.postalAddress}</span>
                                </p>
                                </Grid>
                            </Grid>
                        </Paper>
                    </Grid>
                    
                    <Grid item xs={12} sm={12} md={6}>
                        <Paper className="patientData">
                            <Typography className="title" variant="title">Who is Responsble for Payment</Typography>

                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Medical Scheme</label> <br />
                                    <span> &nbsp;-{props.medicalScheme}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Member Number</label> <br />
                                    <span> &nbsp;-{props.memberNo}</span>
                                </p>
                                </Grid>
                            </Grid>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Prinsiple Member</label> <br />
                                    <span> &nbsp;-1</span>
                                </p>
                                </Grid>

                            </Grid>
                            <div className="braker" />
                            
                            {/* ___________________________________________________________________________ */}
                            <Typography className="title" variant="title">About Payer</Typography>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Name</label> <br />
                                    <span> &nbsp;-{props.payerName}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Last Name</label> <br />
                                    <span> &nbsp;-{props.payerSurname}</span>
                                </p>
                                </Grid>
                            </Grid>
                            
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Street</label> <br />
                                    <span> &nbsp;-{props.medicalPayerStreet}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">City</label> <br />
                                    <span> &nbsp;-{props.medicalPayerCity}</span>
                                </p>
                                </Grid>
                            </Grid>

                            <div className="braker" />
                            
                            {/* ___________________________________________________________________________ */}
                            <Typography className="title" variant="title">My Contact Details</Typography>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Cell Number</label> <br />
                                    <span> &nbsp;-{props.payerCell}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Telephone Number</label> <br />
                                    <span> &nbsp;-{props.payerTel}</span>
                                </p>
                                </Grid>
                            </Grid>
                            <Grid container spacing={8}>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Email</label> <br />
                                    <span> &nbsp;-{props.payerEmail}</span>
                                </p>
                                </Grid>
                                <Grid item xs={6} sm={6}><p>
                                    <label className="label">Postal Address</label> <br />
                                    <span> &nbsp;-123</span>
                                </p>
                                </Grid>
                            </Grid>
                        </Paper>
                    </Grid>                    
                </Grid>
                
            {/* </Paper> */}
        </div>
    )

}
export default ViewPatients